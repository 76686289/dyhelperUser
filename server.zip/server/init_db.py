"""
DYHelper 后台 - 数据库初始化脚本
用法: python3 init_db.py
"""
import sqlite3
import os
from config import DB_PATH, APK_DIR, SERVER_IP, SERVER_URL

def init():
    # 创建目录
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(APK_DIR, exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 白名单表
    c.execute('''
        CREATE TABLE IF NOT EXISTS beta_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT UNIQUE NOT NULL,
            expire TEXT NOT NULL,
            added_at TEXT DEFAULT (datetime('now', 'localtime')),
            note TEXT
        )
    ''')
    
    # 版本表
    c.execute('''
        CREATE TABLE IF NOT EXISTS versions (
            version_code INTEGER PRIMARY KEY,
            version_name TEXT NOT NULL,
            file_name TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            changelog TEXT,
            release_date TEXT DEFAULT (datetime('now', 'localtime')),
            active INTEGER DEFAULT 1
        )
    ''')
    
    # 公告表
    c.execute('''
        CREATE TABLE IF NOT EXISTS notices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            force_update INTEGER DEFAULT 0,
            min_version_code INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            active INTEGER DEFAULT 1
        )
    ''')
    
    # 插入默认公告
    c.execute('SELECT COUNT(*) FROM notices WHERE active=1')
    if c.fetchone()[0] == 0:
        c.execute('''
            INSERT INTO notices (message, force_update, min_version_code, active)
            VALUES (?, 0, 43, 1)
        ''', ("欢迎使用 天天开心^_^ 请不要在抖音评论区或者作品发布任何关于模块UI界面或者信息否则可能小黑屋哦",))
    
    # 插入默认白名单用户
    c.execute('SELECT COUNT(*) FROM beta_users')
    if c.fetchone()[0] == 0:
        c.execute('INSERT INTO beta_users (uid, expire, note) VALUES (?, ?, ?)', 
                  ("91688429578", "2029-12-31", "creator"))
        c.execute('INSERT INTO beta_users (uid, expire, note) VALUES (?, ?, ?)', 
                  ("66646977900", "2029-12-31", "user"))
    
    conn.commit()
    conn.close()
    
    print(f"✓ 数据库已初始化: {DB_PATH}")
    print(f"✓ APK 目录已创建: {APK_DIR}")
    print(f"✓ 服务器 URL: {SERVER_URL}")
    print(f"✓ 默认管理员密码: YMZ5201314lwn@")
    print(f"  (请修改 config.py 改密码)")

if __name__ == '__main__':
    init()
