"""
DYHelper 后台管理系统
基于 Flask + SQLite,单文件应用

启动: python3 app.py
"""
import os
import hashlib
from functools import wraps
from flask import Flask, request, session, redirect, url_for, render_template, jsonify, send_from_directory, flash

from config import ADMIN_PASSWORD, SECRET_KEY, DB_PATH, APK_DIR, HOST, PORT, SERVER_URL

app = Flask(__name__)
app.secret_key = SECRET_KEY

# ===== 认证装饰器 =====
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ===== 数据库辅助 =====
def get_db():
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ===== 路由:登录 =====
@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        password = request.form.get('password', '')
        if password == ADMIN_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        flash('密码错误', 'error')
    return render_template('login.html')

@app.route('/admin/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

# ===== 路由:Dashboard =====
@app.route('/admin/')
@login_required
def dashboard():
    db = get_db()
    stats = {
        'beta_users_count': db.execute('SELECT COUNT(*) FROM beta_users').fetchone()[0],
        'versions_count': db.execute('SELECT COUNT(*) FROM versions WHERE active=1').fetchone()[0],
        'notices_count': db.execute('SELECT COUNT(*) FROM notices WHERE active=1').fetchone()[0],
        'server_url': SERVER_URL,
    }
    db.close()
    return render_template('dashboard.html', stats=stats)

# ===== 路由:白名单管理 =====
@app.route('/admin/beta_users')
@login_required
def beta_users_list():
    db = get_db()
    users = db.execute('SELECT * FROM beta_users ORDER BY added_at DESC').fetchall()
    db.close()
    return render_template('beta_users.html', users=users)

@app.route('/admin/beta_users/add', methods=['POST'])
@login_required
def beta_users_add():
    uid = request.form.get('uid', '').strip()
    expire = request.form.get('expire', '').strip()
    note = request.form.get('note', '').strip()
    
    if not uid or not expire:
        flash('UID 和过期时间不能为空', 'error')
        return redirect(url_for('beta_users_list'))
    
    db = get_db()
    try:
        db.execute('INSERT INTO beta_users (uid, expire, note) VALUES (?, ?, ?)', (uid, expire, note))
        db.commit()
        flash(f'已添加 UID: {uid}', 'success')
    except sqlite3.IntegrityError:
        flash(f'UID {uid} 已存在', 'error')
    db.close()
    return redirect(url_for('beta_users_list'))

@app.route('/admin/beta_users/delete/<int:user_id>', methods=['POST'])
@login_required
def beta_users_delete(user_id):
    db = get_db()
    db.execute('DELETE FROM beta_users WHERE id = ?', (user_id,))
    db.commit()
    db.close()
    flash('已删除', 'success')
    return redirect(url_for('beta_users_list'))

# ===== 路由:版本管理 =====
@app.route('/admin/versions')
@login_required
def versions_list():
    db = get_db()
    versions = db.execute('SELECT * FROM versions ORDER BY version_code DESC').fetchall()
    db.close()
    return render_template('versions.html', versions=versions)

@app.route('/admin/versions/upload', methods=['POST'])
@login_required
def versions_upload():
    version_code = request.form.get('version_code', '').strip()
    version_name = request.form.get('version_name', '').strip()
    changelog = request.form.get('changelog', '').strip()
    file = request.files.get('apk_file')
    
    if not version_code or not version_name or not file:
        flash('版本号、版本名、APK 文件必填', 'error')
        return redirect(url_for('versions_list'))
    
    # 保存 APK
    filename = f"DYHelper{version_name}.apk"
    file_path = os.path.join(APK_DIR, filename)
    file.save(file_path)
    
    # 计算 SHA256 和文件大小
    sha256 = hashlib.sha256(open(file_path, 'rb').read()).hexdigest()
    file_size = os.path.getsize(file_path)
    
    db = get_db()
    try:
        # 把旧版本标记为 inactive
        db.execute('UPDATE versions SET active=0 WHERE active=1')
        # 插入新版本
        db.execute('''
            INSERT INTO versions (version_code, version_name, file_name, sha256, file_size, changelog, active)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        ''', (version_code, version_name, filename, sha256, file_size, changelog))
        db.commit()
        flash(f'版本 {version_name} 上传成功', 'success')
    except sqlite3.IntegrityError:
        flash(f'版本 {version_name} 已存在,请用不同版本号', 'error')
    db.close()
    return redirect(url_for('versions_list'))

@app.route('/admin/versions/delete/<int:version_code>', methods=['POST'])
@login_required
def versions_delete(version_code):
    db = get_db()
    row = db.execute('SELECT file_name FROM versions WHERE version_code = ?', (version_code,)).fetchone()
    if row:
        try:
            os.remove(os.path.join(APK_DIR, row['file_name']))
        except:
            pass
        db.execute('DELETE FROM versions WHERE version_code = ?', (version_code,))
        db.commit()
        flash('版本已删除', 'success')
    db.close()
    return redirect(url_for('versions_list'))

# ===== 路由:公告管理 =====
@app.route('/admin/notices')
@login_required
def notices_list():
    db = get_db()
    notices = db.execute('SELECT * FROM notices ORDER BY created_at DESC').fetchall()
    db.close()
    return render_template('notices.html', notices=notices)

@app.route('/admin/notices/add', methods=['POST'])
@login_required
def notices_add():
    message = request.form.get('message', '').strip()
    force_update = 1 if request.form.get('force_update') else 0
    min_version_code = int(request.form.get('min_version_code', 0) or 0)
    
    if not message:
        flash('公告内容不能为空', 'error')
        return redirect(url_for('notices_list'))
    
    db = get_db()
    db.execute('UPDATE notices SET active=0 WHERE active=1')
    db.execute('INSERT INTO notices (message, force_update, min_version_code, active) VALUES (?, ?, ?, 1)',
               (message, force_update, min_version_code))
    db.commit()
    db.close()
    flash('公告已发布', 'success')
    return redirect(url_for('notices_list'))

@app.route('/admin/notices/delete/<int:notice_id>', methods=['POST'])
@login_required
def notices_delete(notice_id):
    db = get_db()
    db.execute('DELETE FROM notices WHERE id = ?', (notice_id,))
    db.commit()
    db.close()
    flash('公告已删除', 'success')
    return redirect(url_for('notices_list'))

# ===== 公开 API(给 APP 客户端访问)=====

@app.route('/api/beta_users.json')
def api_beta_users():
    """给 APP 客户端拉白名单"""
    db = get_db()
    users = db.execute('SELECT uid, expire FROM beta_users').fetchall()
    notice_row = db.execute('SELECT message FROM notices WHERE active=1 LIMIT 1').fetchone()
    db.close()
    
    return jsonify({
        "update_time": __import__('datetime').datetime.now().strftime("%Y-%m-%d"),
        "notice": notice_row['message'] if notice_row else "",
        "beta_users": [{"uid": u['uid'], "expire": u['expire']} for u in users]
    })

@app.route('/api/blacklist_users.json')
def api_blacklist_users():
    """黑名单(本系统暂无黑名单机制,返回空)"""
    return jsonify({"blacklist_users": []})

@app.route('/api/update.json')
def api_update():
    """给 APP 客户端拉版本更新信息"""
    db = get_db()
    version = db.execute('SELECT * FROM versions WHERE active=1 LIMIT 1').fetchone()
    notice = db.execute('SELECT * FROM notices WHERE active=1 LIMIT 1').fetchone()
    db.close()
    
    if not version:
        return jsonify({"schema_version": 1, "latest": None})
    
    download_url = f"{SERVER_URL}/apk/{version['file_name']}"
    changelog_list = [line.strip() for line in version['changelog'].split('\n') if line.strip()] if version['changelog'] else []
    
    return jsonify({
        "schema_version": 1,
        "latest": {
            "version_code": version['version_code'],
            "version_name": version['version_name'],
            "download_url": download_url,
            "message": notice['message'] if notice else "",
            "changelog": changelog_list,
            "sha256": version['sha256'],
            "file_size": version['file_size'],
            "force_update": bool(notice['force_update']) if notice else False,
            "min_version_code": notice['min_version_code'] if notice else 0,
            "release_date": version['release_date']
        }
    })

@app.route('/apk/<filename>')
def download_apk(filename):
    """APK 下载"""
    return send_from_directory(APK_DIR, filename, as_attachment=True)

# ===== 首页重定向到后台 =====
@app.route('/')
def index():
    return redirect(url_for('login'))

if __name__ == '__main__':
    print(f"========== DYHelper 后台 ==========")
    print(f"服务器 URL: {SERVER_URL}")
    print(f"后台地址: {SERVER_URL}/admin/")
    print(f"管理员密码: {ADMIN_PASSWORD}")
    print(f"==================================")
    app.run(host=HOST, port=PORT, debug=False)
