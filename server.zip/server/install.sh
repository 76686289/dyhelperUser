#!/bin/bash
# DYHelper 后台部署脚本
# 在服务器上执行: bash install.sh
set -e

echo "===== DYHelper 后台部署 ====="

INSTALL_DIR="/opt/dyhelper"
echo "[1/7] 创建目录 $INSTALL_DIR"
mkdir -p $INSTALL_DIR
mkdir -p $INSTALL_DIR/templates
mkdir -p $INSTALL_DIR/static

echo "[2/7] 复制应用文件"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -v $SCRIPT_DIR/app.py          $INSTALL_DIR/
cp -v $SCRIPT_DIR/config.py       $INSTALL_DIR/
cp -v $SCRIPT_DIR/init_db.py      $INSTALL_DIR/
cp -v $SCRIPT_DIR/requirements.txt $INSTALL_DIR/
cp -v $SCRIPT_DIR/templates/*.html $INSTALL_DIR/templates/
cp -v $SCRIPT_DIR/static/*.css    $INSTALL_DIR/static/

echo "[3/7] 安装 Python 依赖"
python3 -m pip install -r $INSTALL_DIR/requirements.txt 2>&1 | tail -3

echo "[4/7] 初始化数据库"
cd $INSTALL_DIR && python3 init_db.py

echo "[5/7] 配置 systemd 服务"
cp -v $SCRIPT_DIR/dyhelper.service /etc/systemd/system/

echo "[6/7] 开放防火墙端口 5173"
if command -v ufw >/dev/null 2>&1; then
    ufw allow 5173/tcp 2>&1 | tail -1
elif command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port=5173/tcp
    firewall-cmd --reload
else
    echo "  (未检测到防火墙工具,请手动放行 5173 端口)"
fi

echo "[7/7] 启动服务"
systemctl daemon-reload
systemctl enable dyhelper
systemctl restart dyhelper
sleep 2
systemctl status dyhelper --no-pager | head -10

echo ""
echo "===== 部署完成 ====="
echo "后台地址: http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_IP'):5173/admin/login"
echo "管理员密码: (见 config.py 的 ADMIN_PASSWORD)"
echo ""
echo "测试 API:"
echo "  curl http://localhost:5173/api/beta_users.json"
echo "  curl http://localhost:5173/api/update.json"
