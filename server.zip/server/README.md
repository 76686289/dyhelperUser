# DYHelper 后台管理系统

## 服务器要求

- Linux (Ubuntu/Debian/CentOS 等)
- root 权限
- Python 3.8+
- 端口 80 可用

## 部署步骤

### 1. 把整个 server 目录上传到服务器

```bash
# 假设你下载了 server 目录,放在 /tmp/server
scp -r server root@110.40.137.43:/tmp/
```

或用 SFTP 工具上传整个 `server/` 文件夹到 `/tmp/server`。

### 2. SSH 登录服务器,执行部署脚本

```bash
ssh root@110.40.137.43
cd /tmp/server
bash install.sh
```

部署脚本会自动:
- 复制文件到 `/opt/dyhelper/`
- 安装 Python 依赖
- 初始化 SQLite 数据库
- 配置 systemd 服务
- 开放防火墙 80 端口
- 启动服务

### 3. 验证部署

浏览器访问:
- 后台: http://110.40.137.43/admin/login
- API: http://110.40.137.43/api/beta_users.json
- API: http://110.40.137.43/api/update.json

### 4. 登录后台

- 地址: http://110.40.137.43/admin/login
- 密码: YMZ5201314lwn@

## 后台功能

### 仪表盘
- 显示白名单用户数、版本数、公告数
- 显示 API 端点列表

### 白名单管理
- 添加白名单用户(uid + 过期时间 + 备注)
- 删除白名单用户
- 查看所有白名单用户

### 版本管理
- 上传新版本 APK
- 自动计算 SHA256 和文件大小
- 自动标记旧版本为历史版本
- 删除版本

### 公告管理
- 发布新公告(支持强制更新、最低兼容版本)
- 删除公告
- 查看所有公告历史

## API 端点(给 APP 客户端)

### GET /api/beta_users.json
返回白名单数据(APP 拉取内测名单):
```json
{
  "update_time": "2026-09-29",
  "notice": "公告内容",
  "beta_users": [
    {"uid": "91688429578", "expire": "2029-12-31"}
  ]
}
```

### GET /api/update.json
返回版本更新信息(APP 拉取更新检查):
```json
{
  "schema_version": 1,
  "latest": {
    "version_code": 44,
    "version_name": "1.4.5",
    "download_url": "http://110.40.137.43/apk/DYHelper1.4.5.apk",
    ...
  }
}
```

### GET /apk/<filename>
下载 APK 文件

## 常用运维命令

```bash
# 查看服务状态
systemctl status dyhelper

# 重启服务
systemctl restart dyhelper

# 停止服务
systemctl stop dyhelper

# 查看日志
journalctl -u dyhelper -f

# 手动编辑配置(改密码等)
nano /opt/dyhelper/config.py
systemctl restart dyhelper

# 备份数据库
cp /opt/dyhelper/data.db /backup/data-$(date +%Y%m%d).db

# 备份 APK 目录
cp -r /opt/dyhelper/apk /backup/
```

## 文件结构

```
/opt/dyhelper/
├── app.py              # Flask 主应用
├── config.py           # 配置(IP、密码、密钥)
├── init_db.py          # 数据库初始化脚本
├── requirements.txt    # Python 依赖
├── data.db             # SQLite 数据库
├── apk/                # APK 上传目录
├── templates/          # HTML 模板
│   ├── login.html
│   ├── dashboard.html
│   ├── beta_users.html
│   ├── versions.html
│   └── notices.html
└── static/             # 静态资源
    └── style.css
```

## 安全提示

⚠️ 当前使用 HTTP(无 HTTPS),密码会明文传输,建议:
1. 后续配域名 + Let's Encrypt 加 HTTPS
2. 改密码后重启服务
3. 定期备份数据库和 APK 目录

## 修改服务器 IP / 域名

如果以后换 IP 或加域名,改 `config.py` 的 `SERVER_IP` 然后重启服务:
```bash
nano /opt/dyhelper/config.py
systemctl restart dyhelper
```

APK 也要重新打包(改 BetaVerifier 里的 URL),所以建议**先确定 IP 再 patch APK**。
