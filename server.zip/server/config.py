"""
DYHelper 后台配置文件
所有敏感配置写这里,不要进 git
"""

# 服务器公网 IP / 域名(用于生成 APK 下载 URL)
SERVER_IP = "110.40.137.43"
SERVER_URL = f"http://{SERVER_IP}"

# 后台管理员密码(单用户模式,登录后用 session)
ADMIN_PASSWORD = "YMZ5201314lwn@"

# Flask secret key(用于 session 签名)
SECRET_KEY = "dyhelper-secret-key-change-me-in-production-2026"

# SQLite 数据库路径
DB_PATH = "/opt/dyhelper/data.db"

# APK 上传/下载目录
APK_DIR = "/opt/dyhelper/apk"

# 监听地址(0.0.0.0 = 所有网卡)
HOST = "0.0.0.0"
PORT = 5173
